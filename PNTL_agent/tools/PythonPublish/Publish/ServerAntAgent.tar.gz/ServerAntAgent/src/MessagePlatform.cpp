
using namespace std;

#include "Sal.h"
#include "Log.h"
#include "MessagePlatform.h"

// ��Serverע��Agent
INT32 ReportToServer(ServerAntAgentCfg_C * pcCfg)
{

    return AGENT_OK;
}

// ��ȡServer��������Ϣ
INT32 GetCfgFromServer(ServerAntAgentCfg_C * pcCfg)
{

    return AGENT_OK;
}

